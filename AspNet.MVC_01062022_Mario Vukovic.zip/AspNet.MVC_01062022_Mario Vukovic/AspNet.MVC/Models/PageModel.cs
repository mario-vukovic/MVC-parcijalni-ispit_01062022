﻿using System.ComponentModel;
using AspNet.MVC.Models.Objects;

namespace AspNet.MVC.Models
{
    public class PageModel
    {
        public List<Author> Authors { get; set; }
        public List<Book> Books { get; set; }

        public PageModel()
        {
            Init();
        }

        private void Init()
        {
            Authors = new List<Author>
            {
                new Author {FirstName = "First Name 1", LastName = "Last Name 1", Title = "Mr."},
                new Author {FirstName = "First Name 2", LastName = "Last Name 2", Title = "Ms."},
                new Author {FirstName = "First Name 3", LastName = "Last Name 3", Title = "Dr."},
            };
            
            Books = new List<Book>
            {
                new Book {Title = "Author 1, Book 1", Author = Authors[0], Genre = "Genre 1"},
                new Book {Title = "Author 2, Book 1", Author = Authors[1], Genre = "Genre 2"},
                new Book {Title = "Author 3, Book 1 ", Author = Authors[2], Genre = "Genre 3"},
                new Book {Title = "Author 1, Book 2", Author = Authors[0], Genre = "Genre 4"},
                new Book {Title = "Author 3, Book 2", Author = Authors[2], Genre = "Genre 9"}
            };
        }
    }
}
