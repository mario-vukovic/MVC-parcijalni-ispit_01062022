﻿namespace AspNet.MVC.Models.Objects
{
    public class Book
    {
        public string Title { get; set; }
        public Author Author { get; set; }
        public string Genre { get; set; }
    }
}
