﻿namespace AspNet.MVC.Models.Objects
{
    public class Author
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }

        public override string ToString()
        {
            return $"{Title} {FirstName} {LastName}";
        }
    }
}
